# Complete Bopomofo reference data preservation payload

This BagIt payload preserves the complete 37-symbol Bopomofo (Zhuyin) table,
its CSVW and MLCommons Croissant metadata, and the companion SKOS vocabulary.

The CSV and its `<CSV filename>-metadata.json` document remain adjacent, so
the relative CSVW `url` continues to resolve after extraction.

## Validate the bag

From the directory containing the BagIt base directory:

```sh
python3 -m pip install bagit==1.9.0
python3 -m bagit --validate bopomofo-37-symbols-bagit
```

BagIt validates transfer integrity, not the semantics of each payload format.
Downstream users should also validate CSVW, Croissant, RDF and SHACL as needed.

Specification: https://www.rfc-editor.org/rfc/rfc8493
Package guide: https://open.cait518.cc/ios-app-guide/data/packages/zhuyin-bopomofo-bagit/
