# Bopomofo CSVW table

This deterministic bundle contains the complete 37-symbol Bopomofo (Zhuyin)
reference table and its W3C CSVW metadata.

## Validate

```sh
python3 -m pip install csvw==4.1.0
csvwvalidate zhuyin-bopomofo-ml-dataset.csv-metadata.json
```

The metadata filename follows CSVW default discovery:
`zhuyin-bopomofo-ml-dataset.csv-metadata.json`.

## Integrity

- `zhuyin-bopomofo-ml-dataset.csv`: `6d9235a013dd1856130841bdf6866f22173903bec726690b9b4c3e555b223422`
- `zhuyin-bopomofo-ml-dataset.csv-metadata.json`: `eb8dcf8e39f65a5d3747a527c58537ad13f8c5a7ae56b55b34189c4ca9a98771`

Verify every bundled file with:

```sh
shasum -a 256 -c checksums-sha256.txt
```

## Standards

- https://www.w3.org/TR/2015/REC-tabular-data-model-20151217/
- https://www.w3.org/TR/2015/REC-tabular-metadata-20151217/
- https://www.w3.org/TR/2015/REC-csv2rdf-20151217/

The table is licensed under CC BY 4.0. The W3C Recommendations describe the
format but do not endorse this dataset or its publisher.
