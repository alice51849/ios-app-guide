# Bopomofo CSVW table

This deterministic bundle contains the complete 37-symbol Bopomofo (Zhuyin)
reference table and its W3C CSVW metadata.

## Validate

```sh
python3 -m pip install csvw==4.1.0
csvwvalidate zhuyin-bopomofo-ml-dataset.csv-metadata.json
```

The metadata filename follows CSVW default discovery:
`zhuyin-bopomofo-ml-dataset.csv-metadata.json`.

## Integrity

- `zhuyin-bopomofo-ml-dataset.csv`: `a6aa93b1523058913ded08f06270ba9520992801ace26762846a88e2e501d514`
- `zhuyin-bopomofo-ml-dataset.csv-metadata.json`: `8fa9e6bc32d3286d08c7e00f96ffd0cc6d9a60ea22e7bcc0b35a289a14fc3677`

Verify every bundled file with:

```sh
shasum -a 256 -c checksums-sha256.txt
```

## Standards

- https://www.w3.org/TR/2015/REC-tabular-data-model-20151217/
- https://www.w3.org/TR/2015/REC-tabular-metadata-20151217/
- https://www.w3.org/TR/2015/REC-csv2rdf-20151217/

The table is licensed under CC BY 4.0. The W3C Recommendations describe the
format but do not endorse this dataset or its publisher.
