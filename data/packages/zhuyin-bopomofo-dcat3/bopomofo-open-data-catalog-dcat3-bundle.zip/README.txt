Bopomofo DCAT 3 open-data catalog
====================================

This deterministic bundle describes 15 Bopomofo datasets and
71 exact published distributions as one static DCAT 3 graph.

Files
-----
- bopomofo-open-data-catalog.dcat.jsonld: DCAT 3 graph in JSON-LD
- bopomofo-open-data-catalog.dcat.ttl: equivalent DCAT 3 graph in Turtle
- checksums.sha256: SHA-256 for both catalog serializations

Validation and scope
--------------------
- Both RDF serializations must parse to the same graph.
- DCAT terms are checked against a pinned unmodified W3C vocabulary.
- Every distribution records direct URL, IANA media-type IRI, byte size,
  CC BY 4.0 license and SPDX SHA-256 checksum.
- This is a static catalog description, not portal registration, W3C
  certification, institutional endorsement or proof of external harvesting.
- Checksums share the same host as the files and therefore provide fixity,
  not an independently protected authenticity channel.

DCAT 3 Recommendation: https://www.w3.org/TR/vocab-dcat-3/
SPDX RDF terms: https://spdx.org/rdf/terms/
Catalog modified: 2026-07-11T20:52:12Z
License: https://creativecommons.org/licenses/by/4.0/
