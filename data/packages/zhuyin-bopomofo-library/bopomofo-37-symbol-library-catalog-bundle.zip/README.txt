Bopomofo 37-Symbol EPUB Library Catalog Records
================================================

This bundle contains two candidate bibliographic records, one for the English EPUB edition and one for the Traditional Chinese edition.

Formats:
- bopomofo-37-symbol-reference.marcxml.xml: MARC 21 XML (MARCXML)
- bopomofo-37-symbol-reference.mods.xml: MODS 3.8 XML
- bopomofo-37-symbol-reference.bibframe.jsonld: BIBFRAME 2.0 JSON-LD
- bopomofo-37-symbol-reference.bibframe.ttl: BIBFRAME 2.0 Turtle
- checksums.sha256: SHA-256 for the four catalog files

Source EPUB page: https://open.cait518.cc/ios-app-guide/data/zhuyin-bopomofo-epub-reference.html
Source metadata: https://open.cait518.cc/ios-app-guide/data/packages/zhuyin-bopomofo-epub/metadata.jsonld
Source modified: 2026-09-04T14:41:43Z
Catalog modified: 2026-09-04T14:41:43Z
English EPUB SHA-256: 748281eadfdd1101548f847bbbe629e7811a0e75664c91f569d0983356342e24
Traditional Chinese EPUB SHA-256: 8dea84b7709babe0a082a6b129a0c7a417d977cee5c4343c9d1ad8ec44bf450b
License: https://creativecommons.org/licenses/by/4.0/

Review local descriptive cataloging, subjects, classification, access and holdings policies before import. These local records do not assign an ISBN, LCCN or OCLC control number.
