Bopomofo 37-Symbol EPUB Library Catalog Records
================================================

This bundle contains two candidate bibliographic records, one for the English EPUB edition and one for the Traditional Chinese edition.

Formats:
- bopomofo-37-symbol-reference.marcxml.xml: MARC 21 XML (MARCXML)
- bopomofo-37-symbol-reference.mods.xml: MODS 3.8 XML
- bopomofo-37-symbol-reference.bibframe.jsonld: BIBFRAME 2.0 JSON-LD
- bopomofo-37-symbol-reference.bibframe.ttl: BIBFRAME 2.0 Turtle
- checksums.sha256: SHA-256 for the four catalog files

Source EPUB page: https://alice51849.github.io/ios-app-guide/data/zhuyin-bopomofo-epub-reference.html
Source metadata: https://alice51849.github.io/ios-app-guide/data/packages/zhuyin-bopomofo-epub/metadata.jsonld
Source modified: 2026-07-11T10:45:50Z
Catalog modified: 2026-07-11T10:45:50Z
English EPUB SHA-256: be0b7cdcc34875930343c41c230fc105f00944e1736d658d9d8de0b67b54cff9
Traditional Chinese EPUB SHA-256: 0e1f335c5b92aa0f2002a7bf130591005df5e36f76335717925f60a206b8e64b
License: https://creativecommons.org/licenses/by/4.0/

Review local descriptive cataloging, subjects, classification, access and holdings policies before import. These local records do not assign an ISBN, LCCN or OCLC control number.
