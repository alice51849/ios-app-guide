# Complete Bopomofo reference data OCFL object

This OCFL 1.1 object preserves the complete 37-symbol Bopomofo (Zhuyin)
table, its CSVW and MLCommons Croissant metadata, and the companion SKOS
vocabulary. It is one OCFL Object, not an OCFL Storage Root.

The CSV and its `<CSV filename>-metadata.json` document remain adjacent in
the logical state, so the relative CSVW `url` resolves after reconstruction.

## Validate the extracted object

```sh
python3 -m pip install ocfl-py==2.1.0
ocfl-validate.py bopomofo-37-symbols-ocfl
```

OCFL validation checks structure, inventory semantics and stored-byte
integrity. Downstream users should also validate CSVW, Croissant, RDF and
SHACL semantics as needed.

Specification: https://ocfl.io/1.1/spec/
Package guide: https://open.cait518.cc/ios-app-guide/data/packages/zhuyin-bopomofo-ocfl/
