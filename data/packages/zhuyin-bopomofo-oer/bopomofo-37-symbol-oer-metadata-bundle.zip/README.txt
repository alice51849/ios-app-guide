Bopomofo OER repository metadata
=================================

This deterministic bundle describes the exact English and Traditional Chinese
editions of the open 37-symbol Bopomofo EPUB.

Files
-----
- bopomofo-37-symbol-reference-en.oai-dc.xml: standalone English OAI-DC record
- bopomofo-37-symbol-reference-zh-hant.oai-dc.xml: standalone Traditional Chinese OAI-DC record
- bopomofo-37-symbol-reference.dcmi-terms.jsonld: DCMI Terms RDF graph in JSON-LD
- bopomofo-37-symbol-reference.lrmi.jsonld: LRMI RDF graph in JSON-LD
- checksums.sha256: SHA-256 for the four metadata files

Validation and scope
--------------------
- OAI-DC XML is validated against pinned official OAI and DCMI schemas.
- JSON-LD uses inline contexts and is parsed without network access.
- LRMI controlled values are supportingDocument and instruction.
- These files are records, not an OAI-PMH endpoint or harvesting service.
- No IMS or IEEE LOM conformance, DOI, institutional approval or universal
  repository compatibility is claimed.
- The resource has no fixed learner age; it is for beginners of any age, with
  adult or educator support for children.

Source manifest: https://alice51849.github.io/ios-app-guide/data/packages/zhuyin-bopomofo-epub/metadata.jsonld
Source modified: 2026-07-11T10:45:50Z
Metadata modified: 2026-07-11T13:00:48Z
English EPUB: https://alice51849.github.io/ios-app-guide/data/packages/zhuyin-bopomofo-epub/bopomofo-37-symbol-reference-en.epub
English SHA-256: be0b7cdcc34875930343c41c230fc105f00944e1736d658d9d8de0b67b54cff9
Traditional Chinese EPUB: https://alice51849.github.io/ios-app-guide/data/packages/zhuyin-bopomofo-epub/bopomofo-37-symbol-reference-zh-hant.epub
Traditional Chinese SHA-256: 0e1f335c5b92aa0f2002a7bf130591005df5e36f76335717925f60a206b8e64b
License: https://creativecommons.org/licenses/by/4.0/
