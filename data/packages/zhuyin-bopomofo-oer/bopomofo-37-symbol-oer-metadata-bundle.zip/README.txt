Bopomofo OER repository metadata
=================================

This deterministic bundle describes the exact English and Traditional Chinese
editions of the open 37-symbol Bopomofo EPUB.

Files
-----
- bopomofo-37-symbol-reference-en.oai-dc.xml: standalone English OAI-DC record
- bopomofo-37-symbol-reference-zh-hant.oai-dc.xml: standalone Traditional Chinese OAI-DC record
- bopomofo-37-symbol-reference.dcmi-terms.jsonld: DCMI Terms RDF graph in JSON-LD
- bopomofo-37-symbol-reference.lrmi.jsonld: LRMI RDF graph in JSON-LD
- checksums.sha256: SHA-256 for the four metadata files

Validation and scope
--------------------
- OAI-DC XML is validated against pinned official OAI and DCMI schemas.
- JSON-LD uses inline contexts and is parsed without network access.
- LRMI controlled values are supportingDocument and instruction.
- These files are records, not an OAI-PMH endpoint or harvesting service.
- No IMS or IEEE LOM conformance, DOI, institutional approval or universal
  repository compatibility is claimed.
- The resource has no fixed learner age; it is for beginners of any age, with
  adult or educator support for children.

Source manifest: https://open.cait518.cc/ios-app-guide/data/packages/zhuyin-bopomofo-epub/metadata.jsonld
Source modified: 2026-09-04T14:41:43Z
Metadata modified: 2026-09-04T14:41:43Z
English EPUB: https://open.cait518.cc/ios-app-guide/data/packages/zhuyin-bopomofo-epub/bopomofo-37-symbol-reference-en.epub
English SHA-256: 748281eadfdd1101548f847bbbe629e7811a0e75664c91f569d0983356342e24
Traditional Chinese EPUB: https://open.cait518.cc/ios-app-guide/data/packages/zhuyin-bopomofo-epub/bopomofo-37-symbol-reference-zh-hant.epub
Traditional Chinese SHA-256: 8dea84b7709babe0a082a6b129a0c7a417d977cee5c4343c9d1ad8ec44bf450b
License: https://creativecommons.org/licenses/by/4.0/
